<?php

$connect = new PDO("mysql:host=localhost; dbname=lms2", "root", "");
session_start();

?>